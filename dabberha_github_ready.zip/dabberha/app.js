const $=s=>document.querySelector(s), requestsKey='dabberha_requests_v1', profileKey='dabberha_profile_v1';
const getRequests=()=>JSON.parse(localStorage.getItem(requestsKey)||'[]');
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function card(r){return `<article class="request"><h3>${esc(r.title)}</h3><div class="meta"><span class="tag">${esc(r.category)}</span><span>📍 ${esc(r.area)}</span><span>${new Date(r.created).toLocaleDateString('ar-JO')}</span></div>${r.details?`<p>${esc(r.details)}</p>`:''}</article>`}
function render(){const all=getRequests();$('#requestCount').textContent=`${all.length} طلب`;$('#requests').innerHTML=all.length?all.slice().reverse().map(card).join(''):'';$('#empty').hidden=all.length>0;$('#myRequests').innerHTML=all.length?all.slice().reverse().map(card).join(''):'<div class="empty">ما أضفت طلبات لحد الآن.</div>'}
function openRequest(category=''){const f=$('#requestForm');f.reset();if(category)f.elements.category.value=category;$('#requestDialog').showModal()}
$('#newRequestTop').onclick=()=>openRequest();$('#newRequestNav').onclick=()=>openRequest();
document.querySelectorAll('.cat').forEach(b=>b.onclick=()=>openRequest(b.dataset.cat));
$('#requestForm').onsubmit=e=>{e.preventDefault();const d=new FormData(e.currentTarget);const r=Object.fromEntries(d.entries());r.id=crypto.randomUUID?crypto.randomUUID():String(Date.now());r.created=new Date().toISOString();const a=getRequests();a.push(r);localStorage.setItem(requestsKey,JSON.stringify(a));$('#requestDialog').close();render();toast('تم حفظ طلبك على هذا الجهاز')};
function openProfile(){const p=JSON.parse(localStorage.getItem(profileKey)||'{}');const f=$('#profileForm');f.elements.name.value=p.name||'';f.elements.phone.value=p.phone||'';$('#profileDialog').showModal()}
$('#profileBtn').onclick=openProfile;$('#profileNav').onclick=openProfile;
$('#profileForm').onsubmit=e=>{e.preventDefault();const d=new FormData(e.currentTarget);localStorage.setItem(profileKey,JSON.stringify(Object.fromEntries(d.entries())));$('#profileDialog').close();toast('تم حفظ بياناتك على الجهاز')};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
document.querySelectorAll('[data-scroll]').forEach(b=>b.onclick=()=>{const id=b.dataset.scroll;if(id==='top')window.scrollTo({top:0,behavior:'smooth'});else document.getElementById(id).scrollIntoView({behavior:'smooth'})});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();